<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script setup>
  import { onMounted } from 'vue'

  onMounted(() => {
    console.log('Window', window);
  })
</script>

<style lang="scss">
  #app {
    width: 100%;
  }
</style>
