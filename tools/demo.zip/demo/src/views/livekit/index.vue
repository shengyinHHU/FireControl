<template>
  <div class="contain">

    <div class="tip-box" v-if="isJoinRoom">
      提示：<br />
      1、推流：用户点击推流，自动生成推流地址，SDK会将当前视频推送至指定服务器地址；<br />
      2、拉流：用户点击拉流，自动生成拉流地址，SDK会将已经上传至拉流地址的视频拉入房间；<br />
      3、邀请：点击邀请，分享给其他用户，其他用户可以通过链接直接进入房间。
    </div>
    <div class="tip-box" v-else>
      提示：<br />
      1、输入后台管理系统中已经维护的账号和密码，点击【登陆】进行登录，然后输入房间名，点击【创建房间】即可创建房间；<br />
    </div>
    <el-form :model="liveForm" label-position="right" label-width="100px">
      <el-row :gutter="20" style="margin-bottom: 40px">
        <el-col :span="6">
          <el-form-item label="用户名" prop="userName">
            <el-input v-model="liveForm.userName"></el-input>
          </el-form-item>
        </el-col>
        <!-- <el-col :span="6">
          <el-form-item label="密码" prop="loginKey">
            <el-input type="password" v-model="liveForm.loginKey"></el-input>
          </el-form-item>
        </el-col> -->
        <el-col :span="6">
          <el-form-item label="房间名" prop="roomName">
            <el-input v-model="liveForm.roomName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="房间号" prop="roomNumber">
            <el-input v-model="liveForm.roomNumber"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-bottom: 40px">
        <el-col :span="6">
          <el-form-item label="音频设备" prop="audioDevice">
            <el-select v-model="liveForm.audioDevice">
              <el-option
                v-for="item of audioDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="视频设备" prop="videoDevice">
            <el-select v-model="liveForm.videoDevice">
              <el-option
                v-for="item of videoDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="输出设备" prop="outputDevice">
            <el-select v-model="liveForm.outputDevice">
              <el-option
                v-for="item of outputDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-bottom: 40px">
        <el-col :span="6">
          <el-form-item label="拉流地址" prop="videoUrl">
            <el-input v-model="liveForm.videoUrl"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="推流地址" prop="pushVideoUrl">
            <el-input v-model="liveForm.pushVideoUrl"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="btn-list">
      <!-- <el-button type="primary" plain class="btn" @click="login">登录</el-button> -->
      <el-button type="primary" plain class="btn" @click="createRoom">创建房间</el-button>
      <el-button type="primary" plain class="btn" @click="enterRoom">加入房间</el-button>
      <el-button type="danger" plain class="btn" @click="exitRoom">退出房间</el-button>
      <template v-if="isJoinRoom">
        <el-button type="primary" plain class="btn" @click="changeCameraStatus"
          >{{ isLocalCameraEnable ? '禁用摄像头' : '启用摄像头' }}</el-button
        >

        <el-button type="primary" plain class="btn" @click="changeMicrophoneStatus"
          >{{ isLocalMicrophoneEnable ? '禁用麦克风' : '启用麦克风' }}</el-button
        >
        <div class="btn" v-if="!isPushing">
          <el-button type="primary" plain @click="pushStream">推流</el-button>
          <el-tooltip effect="light" placement="bottom-start">
            <template #content>
              推流<br />
              将视频的内容推送至服务器的过程。<br />
              即指的是把采集阶段封包好的内容传输到服务器的过程。<br />

              1、点击前须先加入房间<br />
              2、点击推流后将向指定节点推流，并在推流地址字段返回当前推流地址
            </template>
            <div class="btn-icon"></div>
          </el-tooltip>
        </div>
        <el-button type="primary" plain class="btn" @click="stopPushStream" v-else>停止推流</el-button>
        <div class="btn" v-if="!isPulling">
          <!-- <div class="btn" v-if="!isPulling"> -->
          <el-button type="primary" plain @click="pullStream">拉流</el-button>
          <el-tooltip effect="light" placement="bottom-start">
            <template #content>
              拉流<br />
              指服务器已有视频内容，用指定地址进行拉取的过程。<br />
              即是指服务器里面有流媒体视频文件，这些视频文件根据<br />
              不同的网络协议类型被读取的过程。<br />
              1、点击前须先加入房间，并输入拉流地址<br />
              2、点击后将开始拉流
            </template>
            <div class="btn-icon"></div>
          </el-tooltip>
        </div>
        <el-button type="primary" plain class="btn" @click="stopPullStream" v-else>停止拉流</el-button>
        <el-button type="primary" plain class="btn" @click="startRecord" v-if="!isRecording">开始录制</el-button>
        <el-button type="primary" plain class="btn" @click="stopRecord" v-else>
          <i class="record-icon"></i>停止录制</el-button>
        <el-button type="primary" plain class="btn" @click="screenShot">截屏</el-button>
        <!-- <el-button type="primary" plain class="btn" @click="publishOtherVideo">推第三方视频</el-button> -->

        <el-button type="primary" plain class="btn" @click="controlShareScreen"
          >{{ isLocalSreenShareEnable ? '取消共享屏幕' : '共享屏幕' }}</el-button
        >

        <el-button type="primary" plain class="btn" @click="invite">PC邀请</el-button>
        <el-button type="primary" plain class="btn" @click="miniInvite">小程序邀请</el-button>
        <el-button type="primary" plain class="btn" @click="outCallInvite">外呼邀请</el-button>
      </template>
    </div>
    <div id="video-wrap"></div>
    <div id="screenshare-area" v-show="isScreenShareShow">
      <div>
        <span id="screenshare-info"></span>
        <span id="screenshare-resolution"></span>
      </div>
      <video id="screenshare-video" autoplay playsinline></video>
    </div>
    <div id="img-box">
      <h5>屏幕截图</h5>
      <img v-if="imgUrl" class="img-show" :src="imgUrl" alt="" />
    </div>
  </div>
  <el-dialog title="邀请链接" width="30%" v-model="inviteDialogShow" modal>
    <div class="link-content" id="link-content">
      <div class="link-title">{{ userId + " " + "邀请您参加视频会议" }}</div>
      <div class="link-list">
        <div class="list-title">房间名：{{ liveForm.roomName }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">房间号：{{ liveForm.roomNumber }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">房间链接：{{ liveForm.roomLink }}</div>
      </div>
      <div class="link-btn">
        <el-button id="copy-btn" type="info" style="padding: 0 10px" @click="copyLink"
          >一键复制</el-button
        >
      </div>
    </div>
  </el-dialog>
  <el-dialog title="邀请链接" width="30%" v-model="miniInviteDialogShow" modal>
    <div class="link-content" id="mini-link-content">
      <div class="link-title">{{ userId + " " + "邀请您参加视频会议,请通过小程序打开链接" }}</div>
      <div class="link-list">
        <div class="list-title">房间名：{{ liveForm.roomName }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">房间号：{{ liveForm.roomNumber }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">小程序链接：{{ miniLink }}</div>
      </div>
      <div class="link-btn">
        <el-button id="copy-btn2" type="info" style="padding: 0 10px" @click="copyLink2"
          >一键复制</el-button
        >
      </div>
    </div>
  </el-dialog>
  <el-dialog title="外呼邀请" width="30%" v-model="outCallDialogShow" modal>
    <div class="makecall">
      <el-form :model="outCallForm" label-position="left" label-width="140px">
        <el-row :gutter="20" style="margin-bottom: 40px" justify="center">
          <el-col :span="18">
            <el-form-item label="受邀者入会姓名" prop="invitedName">
              <el-input v-model="outCallForm.invitedName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-bottom: 40px" justify="center">
          <el-col :span="18">
            <el-form-item label="电话号码" prop="v">
              <el-input v-model="outCallForm.phone"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="dialog-bottom">
        <el-button type="primary" plain class="btn" @click="voiceOutCall">语音呼叫</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
import { reactive, ref, watch, onMounted } from "vue";
import { ElMessage } from "element-plus";
import ClipboardJS from "clipboard";
import { LiveClient } from "@/utils/livekit/index";
import { getMiniLink } from "@/api/index"
const baseUrl = window['$baseUrl']
const linkBaseUrl = window['$linkBaseUrl']
const liveForm = reactive({
  userName: "",
  loginKey: "",
  roomName: "",
  roomNumber: "",
  audioDevice: "",
  videoDevice: "",
  outputDevice: "",
  // pullMode: 'auto',
  echoCancellation: "0",
  autoGain: "0",
  noiseCancellation: "0",
  videoUrl: "",
  pushVideoUrl: "",
  currentUser: "",
  roomLink: "",
});
const outCallForm = reactive({
  invitedName: "",
  phone: ""
})
let outCallDialogShow = ref(false)

let audioDeviceList = ref([]),
  videoDeviceList = ref([]),
  outputDeviceList = ref([])
let imgUrl = ref("");
let liveClient = null;
let isScreenShareShow = ref(false);
let userId = ref(null);
let org = ref(null);
let token = ref(null);
// let screenShotOrg = ref(null)
let inviteDialogShow = ref(false);
let miniInviteDialogShow = ref(false)
let miniLink = ref('')
// 控制推流按钮展示
let isPushing = ref(false)
// 控制录制按钮展示
let isRecording = ref(false)
// 控制拉流按钮展示
let isPulling = ref(false)
// 控制摄像头按钮展示
let isLocalCameraEnable = ref(true)
// 控制麦克风按钮展示
let isLocalMicrophoneEnable = ref(true)
let isLocalSreenShareEnable = ref(false)
let isJoinRoom = ref(false)
watch(
  () => liveForm.audioDevice,
  (audioDevice) => {
    if (liveClient) {
      liveClient.changeAudioDevice(audioDevice);
    }
  }
);
watch(
  () => liveForm.videoDevice,
  (videoDevice) => {
    if (liveClient) {
      liveClient.changeVideoDevice(videoDevice);
    }
  }
);
watch(
  () => liveForm.outputDevice,
  (outputDevice) => {
    if (liveClient) {
      liveClient.changeOutputDevice(outputDevice);
    }
  }
);
const login = async () => {
  let loginParams = {
    rememberme: "1",
    username: liveForm.userName.split("@")[0],
    tenantAccount: liveForm.userName.split("@")[1],
    password: liveForm.loginKey,
  };
  let result = null;
  try {
    let response = await fetch(linkBaseUrl + "/api/system/loginNew", {
      method: "POST",
      headers: {
        "Content-Type": "application/json;charset=utf-8",
      },
      body: JSON.stringify(loginParams),
    });
    if(response.status == 200) {
      result = await response.json();
    } else {
      ElMessage({
        message: "用户登录失败",
        type: "error",
      });
    }
  } catch (err) {
    ElMessage({
      message: "用户登录失败",
      type: "error",
    });
  }
  if (result) {
    ElMessage({
      message: "用户登录成功",
      type: "success",
    });
    // localStorage.setItem("token", result.token);
    localStorage.setItem("username", loginParams.username);
    localStorage.setItem("org", "default");
  }
};
const exitRoom = () => {
  if (liveClient) {
    liveClient.leaveRoom();
    liveClient = null;
  }
  location.reload();
};
const initRoomEvent = () => {
  // console.log('initEvent', liveClient);
  if (!liveClient) {
    return;
  }
  liveClient.on("activeSpeakerChange", (e) => {
    console.log('当前正在讲话', e)
  })
  liveClient.on("makeCallSuccess", (e) => {
    ElMessage({
      message: "外呼成功",
      type: "success",
    });
    outCallDialogShow.value = false
  });
  liveClient.on("roomCreatedSuccess", (e) => {
    console.log("roomCreatedSuccess", e);
    ElMessage({
      message: "房间创建成功，房间号为" + e,
      type: "success",
    });
  });
  liveClient.on("roomCreatedFail", (e) => {
    console.log("roomCreatedFail", e);
    ElMessage({
      message: "房间创建失败，请重试",
      type: "error",
    });
  });
  liveClient.on("roomConnected", (e) => {
    console.log("roomConnected", e);
    ElMessage({
      message: "房间连接成功",
      type: "success",
    });
    isJoinRoom.value = true
    // console.log('room', liveClient?.room);
  });
  liveClient.on("joinRoomError", (e) => {
    console.log("joinRoomError", e);
    ElMessage({
      message: "加入房间失败，请重试",
      type: "error",
    });
    isJoinRoom.value = false
  });
  liveClient.on("roomDisconnected", (e) => {
    console.log("roomDisconnected", e);
    ElMessage({
      message: "房间连接已关闭",
      type: "error",
    });
    isJoinRoom.value = false
    exitRoom()
  });
  liveClient.on("localCameraChange", (e) => {
    console.log("localCameraChange", e);
    let message = "";
    isLocalCameraEnable.value = e
    if (e) {
      message = "摄像头已打开";
    } else {
      message = "摄像头已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("localMicrophoneChange", (e) => {
    console.log("localMicrophoneChange", e);
    let message = "";
    isLocalMicrophoneEnable.value = e
    if (e) {
      message = "麦克风已打开";
    } else {
      message = "麦克风已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("localScreenShareChange", (e) => {
    console.log("localScreenShareChange", e);
    let message = "";
    isLocalSreenShareEnable.value = e
    if (e) {
      message = "屏幕共享已打开";
    } else {
      message = "屏幕共享已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("startPushing", (e) => {
    console.log("startPushing", e);
    ElMessage({
      message: "开始视频推流",
      type: "success",
    });
    isPushing.value = true
  });
  liveClient.on("stopPushing", (e) => {
    console.log("stopPushing", e);
    ElMessage({
      message: "停止视频推流",
      type: "success",
    });
    isPushing.value = false
  });
  liveClient.on("startRecording", (e) => {
    console.log("startRecording", e);
    ElMessage({
      message: "开始录制",
      type: "success",
    });
    isRecording.value = true
  });
  liveClient.on("stopRecording", (e) => {
    console.log("stopRecording", e);
    ElMessage({
      message: "停止录制",
      type: "success",
    });
    isRecording.value = false
  });
  liveClient.on("startPulling", (e) => {
    console.log("startPulling", e);
    ElMessage({
      message: "开始拉流",
      type: "success",
    });
    isPulling.value = true
    liveForm.videoUrl = e
  });
  liveClient.on("stopPulling", (e) => {
    console.log("stopPulling", e);
    ElMessage({
      message: "停止拉流",
      type: "success",
    });
    isPulling.value = false
  });
  liveClient.on("imageUploadSuccess", (e) => {
    console.log("imageUploadSuccess", e);
    imgUrl.value = e;
    ElMessage({
      message: "截屏保存成功",
      type: "success",
    });
  });
  liveClient.on("imageUploadFail", (e) => {
    console.log("imageUploadFail", e);
    ElMessage({
      message: "截屏保存失败，请检查接口后重试",
      type: "error",
    });
  });
  liveClient.on("videoCallRender", (e) => {
    console.log("视频通话渲染" + e.identity + ":", e);
    // const reg = /^(sip_)+?/
    if(liveClient) {
      isLocalCameraEnable.value = liveClient.isCameraEnable
      isLocalMicrophoneEnable.value = liveClient.isMicrophoneEnable
      isLocalSreenShareEnable.value = liveClient.isScreenShareEnabled
    }
    const container = document.getElementById("video-wrap");
    if (!container) {
      ElMessage({
        message: "视频会议容器不存在",
        type: "error",
      });
      return;
    }
    let div = document.getElementById(`participant-${e.identity}`);
    if (!div && !e.remove) {
      div = document.createElement("div");
      div.id = `participant-${e.identity}`;
      div.className = "participant";
      div.innerHTML = `
        <video id="video-${e.identity}" class="p-video" autoplay></video>
        <div class="describe">
          <div id="${e.identity}" class="identity">${e.name}</div>
          <div class="tools">
            <div id="hangoff-${e.identity}" class="hangoff"></div>
            <div id="camera-${e.identity}" class="camera"></div>
            <div id="microphone-${e.identity}" class="microphone"></div>
          </div>
        </div>
      `;
      container.appendChild(div);
    }
    let videoElm = document.getElementById(`video-${e.identity}`);
    if(videoElm) {
      videoElm.controls = true
    }
    let microphoneElm = document.getElementById(`microphone-${e.identity}`);
    let cameraElm = document.getElementById(`camera-${e.identity}`);
    let hangoffElm = document.getElementById(`hangoff-${e.identity}`);
    const unableMicrophone = () => {
      liveClient.changeParticipantMicrophoneStatus(e.identity, true);
    };
    const enableMicrophone = () => {
      liveClient.changeParticipantMicrophoneStatus(e.identity, false);
    };
    const moveoutParticipant = () => {
      liveClient.moveoutParticipant(e.identity)
    }
    if (microphoneElm && e.isMicrophoneEnabled) {
      microphoneElm.className = "microphone microphone-active";
      microphoneElm.onclick = unableMicrophone;
    } else if (microphoneElm && !e.isMicrophoneEnabled) {
      microphoneElm.className = "microphone microphone-inactive";
      microphoneElm.onclick = enableMicrophone;
    }
    if (cameraElm && e.isCameraEnabled) {
      cameraElm.className = "camera camera-active";
      cameraElm.onclick = () => {
        liveClient.changeParticipantCameraStatus(e.identity, true);
      };
    } else if (cameraElm && !e.isCameraEnabled) {
      cameraElm.className = "camera camera-inactive";
      cameraElm.onclick = () => {
        liveClient.changeParticipantCameraStatus(e.identity, false);
      };
    }
    if(hangoffElm) {
      hangoffElm.onclick = moveoutParticipant
    }
    if (e.remove) {
      if (videoElm) {
        videoElm.srcObject = null;
        videoElm.src = "";
        videoElm?.remove();
        videoElm = null
      }
      if (e.videoTrack) {
        e.videoTrack.detach(videoElm);
      }
      if (e.audioTrack) {
        e.audioTrack.detach(videoElm);
      }
      if (div) {
        div?.remove();
      }
      return;
    }
    if (e.videoTrack) {
      e.videoTrack.attach(videoElm);
    }
    if (e.audioTrack) {
      e.audioTrack.attach(videoElm);
    }
    
  });
  liveClient.on("requestDeviceOpen", (e) => {
    console.log("房主请求打开设备", e);
    if (e.input == "1") {
      ElMessage({
        message: "房主请求与会者打开麦克风",
        type: "success",
      });
    } else if (e.input == "2") {
      ElMessage({
        message: "房主请求与会者打开摄像头",
        type: "success",
      });
    }
  });
};
const setInviteLink = () => {
  let org = localStorage.getItem("org")
  return `${window['$linkBaseUrl']}#/invite?roomName=${liveForm.roomName}&roomNum=${liveForm.roomNumber}&org=${org}`;
};
const createRoom = async () => {
  localStorage.setItem("username", liveForm.userName);
  localStorage.setItem("org", "default");
  userId.value = localStorage.getItem("username");
  org.value = localStorage.getItem("org");
  if (liveForm.roomName === "") {
    console.log("请输入房间名，房间名不能为空");
    return;
  }
  if (!userId.value || !org.value) {
    console.log("创建房间前请先登录");
    return;
  }
  let param = {
    userId: userId.value,
    org: org.value,
    roomName: liveForm.roomName,
    roomMode: "auto",
    baseUrl: baseUrl
  };
  liveClient = new LiveClient(param);
  initRoomEvent();
  liveForm.roomNumber = await liveClient.createRoom();
  liveForm.roomLink = setInviteLink();
  let joinRoomParam = {
    audioDeviceId: liveForm.audioDevice,
    videoDeviceId: liveForm.videoDevice,
    outputDeviceId: liveForm.outputDevice,
    autoGainControl: liveForm.autoGain,
    echoCancellation: liveForm.echoCancellation,
    noiseSuppression: liveForm.noiseCancellation,
    roomNum: liveForm.roomNumber,
  };
  let activeDevice = null;
  activeDevice = await liveClient.joinRoom(joinRoomParam);
  console.log("activeDevice", activeDevice);
  liveForm.audioDevice = activeDevice.audioInputDevice;
  liveForm.videoDevice = activeDevice.videoInputDevice;
  liveForm.outputDevice = activeDevice.audioOutputDevice;
};
const enterRoom = async () => {
  userId.value = localStorage.getItem("username");
  org.value = localStorage.getItem("org");
  let param = {
    audioDeviceId: liveForm.audioDevice,
    videoDeviceId: liveForm.videoDevice,
    outputDeviceId: liveForm.outputDevice,
    autoGainControl: liveForm.autoGain,
    echoCancellation: liveForm.echoCancellation,
    noiseSuppression: liveForm.noiseCancellation,
    roomNum: liveForm.roomNumber,
  };
  let param2 = {
    userId: userId.value,
    org: org.value,
    roomName: liveForm.roomName,
    roomMode: "auto",
    baseUrl: baseUrl
  };
  let activeDevice = null;
  if (liveClient) {
    activeDevice = await liveClient.joinRoom(param);
  } else {
    liveClient = new LiveClient(param2);
    initRoomEvent();
    activeDevice = await liveClient.joinRoom(param);
  }
  console.log("activeDevice", activeDevice);
  liveForm.audioDevice = activeDevice.audioInputDevice;
  liveForm.videoDevice = activeDevice.videoInputDevice;
  liveForm.outputDevice = activeDevice.audioOutputDevice;
};
const changeCameraStatus = () => {
  liveClient.changeCameraStatus();
};
const changeMicrophoneStatus = () => {
  liveClient.changeMicrophoneStatus();
};
const screenShot = async () => {
  if(!liveClient) {
    return;
  }
  let config = {
    width: 400,
    height: 280,
    quality: 1,
  };
  let localId = `video-${liveClient.room.localParticipant.identity}`
  let localDom = document.getElementById(localId)
  if(localDom) {
    await liveClient.uploadScreenShot(localId, config);
  } else {
    console.error('要截图的元素id不存在，请确认是否加入房间');
  }
};
const pushStream = async () => {
  let result = await liveClient.pushVideoStream();
  liveForm.pushVideoUrl = result;
};
const startRecord = async () => {
  await liveClient.startRecord();
};
const stopRecord = async () => {
  await liveClient.stopRecord();
};
const pullStream = async () => {
  await liveClient.pullStream(liveForm.videoUrl, ("stream_" + new Date().getTime().toString(36)) + Math.ceil(Math.random() * 10000));
};
const stopPullStream = async () => {
  await liveClient.stopPullStream();
};
const stopPushStream = async () => {
  await liveClient.stopPushVideoStream();
};
const controlShareScreen = () => {
  liveClient.changeScreenShareStatus();
};
const invite = () => {
  if (!userId.value) {
    ElMessage({
      message: "无法获取到用户名，请先登录",
      type: "error",
    });
    return;
  } else if (!liveForm.roomName) {
    ElMessage({
      message: "无法获取房间名",
      type: "error",
    });
    return;
  } else if (!liveForm.roomNumber) {
    ElMessage({
      message: "无法获取房间号，请确认房间是否创建",
      type: "error",
    });
    return;
  } else if (!liveForm.roomLink) {
    ElMessage({
      message: "无法获取房间链接",
      type: "error",
    });
    return;
  }
  inviteDialogShow.value = true;
};
const miniInvite = () => {
  if (!userId.value) {
    ElMessage({
      message: "无法获取到用户名，请先登录",
      type: "error",
    });
    return;
  } else if (!liveForm.roomName) {
    ElMessage({
      message: "无法获取房间名",
      type: "error",
    });
    return;
  } else if (!liveForm.roomNumber) {
    ElMessage({
      message: "无法获取房间号，请确认房间是否创建",
      type: "error",
    });
    return;
  }
  let param = {
    path: '/pages/demo/demo',
    query: encodeURI(`roomName=${liveForm.roomName}&roomNum=${liveForm.roomNumber}&tenantId=1478649882954985474`),
    env_version: 'develop'
  }
  getMiniLink(param).then(res => {
    console.log('生成小程序接口返回', res)
  })
  // miniInviteDialogShow.value = true
}
const copyLink = () => {
  let clipboard = new ClipboardJS("#copy-btn", {
    target: () => {
      return document.getElementById("link-content");
    },
  });
  // clipboard.on('success', (e) => {
  //   console.log('已复制', e);
  // })
  // clipboard.on('error', (e) => {
  //   console.log('报错', e);
  // })
};
const copyLink2 = () => {
  let clipboard = new ClipboardJS("#copy-btn2", {
    target: () => {
      return document.getElementById("mini-link-content");
    },
  });
}
const outCallInvite = () => {
  outCallDialogShow.value = true
  outCallForm.invitedName = ""
  outCallForm.phone = ""
}
const voiceOutCall = async () => {
  if(!outCallForm.invitedName || !outCallForm.phone) {
    ElMessage({
      message: "请先输入受邀者入会姓名和手机号",
      type: "error",
    });
  }
  await liveClient.makeCall(outCallForm.invitedName, outCallForm.phone)
}
onMounted(async () => {
  const { audioDevices, videoDevices, outputDevices } = await LiveClient.getDeviceList();
  audioDeviceList.value = audioDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
  videoDeviceList.value = videoDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
  outputDeviceList.value = outputDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
});
</script>

<style lang="scss" scoped>
// @import "./style.scss";
.contain {
  width: 100%;
  padding-top: 10px;
  position: relative;
  .tip-box {
    width: 100%;
    background-color: #f4ce98;
    padding: 10px 20px;
    margin-bottom: 20px;
    font-size: 14px;
    line-height: 22px;
  }
  .btn-list {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    padding-left: 30px;
    margin-bottom: 20px;
    ::v-deep .el-button {
      min-width: 88px;
      padding: 0 10px;
    }
    .btn {
      position: relative;
      margin-right: 15px;
      .btn-icon {
        cursor: pointer;
        position: absolute;
        top: 2px;
        right: 2px;
        width: 12px;
        height: 12px;
        background: url("../../assets/image/demo/tip.png") no-repeat center / 100% 100%;
      }
    }
  }
  .record-icon {
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 10px;
    background: url('../../assets/image/demo/record.png') no-repeat center / 100% 100%;
  }
}
#img-box {
  margin-top: 20px;
  margin-bottom: 20px;
  h5 {
    padding-left: 20px;
    position: relative;
    &::before {
      content: '';
      width: 4px;
      height: 80%;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      position: absolute;
      background-color: #4868A9;
    }
  }
  .img-show {
    width: 460px;
    height: 280px;
  }
}
#screenshare-area {
  position: relative;
  margin-top: 20px;
  margin-bottom: 20px;
  // display: none;
}

#screenshare-area video {
  width: 800px;
  height: 400px;
  object-fit: fill;
  border: 3px solid rgba(0, 0, 0, 0.5);
}
.link-content {
  width: 100%;
  font-size: 14px;
  color: #000;
  padding-top: 30px;
  padding-bottom: 20px;
  border-top: 1px solid rgba(0, 0, 0, 0.4);
  .link-list {
    width: 100%;
    display: flex;
    align-items: flex-start;
    margin-top: 15px;
    .list-title {
      line-height: 23px;
      white-space: wrap;
    }
    // .list-content {
    //   line-height: 23px;
    //   white-space: wrap;
    // }
  }
  .link-btn {
    margin-top: 10px;
    width: 100%;
    display: flex;
    justify-content: center;
  }
}
.dialog-bottom {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
  .btn {
    padding: 0 10px;
  }
}
.makecall {
  padding-top: 20px;
  padding-bottom: 20px;
  :deep(.el-form-item) {
    display: block;
  }
  :deep(.el-form-item__content) {
    padding-left: 20px;
  }
}
</style>
<style lang="scss">
  .el-dialog__body {
    padding: 0 20px;
  }
</style>