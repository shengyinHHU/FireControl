<template>
  <div class="contain">
    <div class="tip-box">
      提示：<br />
      1、输入后台管理系统中已经维护的账号和密码，点击【登陆】进行登录，然后输入房间名，点击【创建房间】即可创建房间；<br />
    </div>
    <el-form :model="liveForm" label-position="right" label-width="100px">
      <el-row :gutter="20" style="margin-bottom: 20px;">
        <el-col :span="6">
          <el-form-item label="用户名" prop="userName">
            <el-input v-model="liveForm.userName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="密码" prop="loginKey">
            <el-input type="password" v-model="liveForm.loginKey"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-bottom: 20px;">
        <el-col :span="6">
          <el-form-item label="房间名" prop="roomName">
            <el-input v-model="liveForm.roomName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="房间号" prop="roomNumber">
            <el-input v-model="liveForm.roomNumber"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="音频设备" prop="audioDevice">
            <el-select v-model="liveForm.audioDevice">
              <el-option
               v-for="item of audioDeviceList"
               :key="item.value"
               :label="item.label"
               :value="item.value"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="btn-list">
      <el-button type="primary" plain class="btn" @click="login">登录</el-button>
      <el-button type="primary" plain class="btn" @click="createRoom">创建房间</el-button>
      <el-button type="primary" plain class="btn" @click="enterRoom">加入房间</el-button>
      <el-button type="danger" plain class="btn" @click="exitRoom">退出房间</el-button>
      <template v-if="isJoinRoom">
        <el-button type="primary" plain class="btn" @click="changeMicrophoneStatus">启用/禁用麦克风</el-button>
        <el-button type="primary" plain class="btn" @click="outCallInvite">外呼邀请</el-button>
      </template>
    </div>
  </div>
  <div id="video-wrap">
    <!-- <div class="participant">
      <video src="" class="p-video"></video>
      <div class="describe">
        <div class="identity">测试</div>
        <div class="tools">
          <div class="microphone microphone-active microphone-inactive"></div>
        </div>
      </div>
    </div> -->
  </div>
  <div id="audio-wrap">
  </div>
  <el-dialog title="外呼邀请" width="30%" v-model="outCallDialogShow" modal>
    <div class="makecall">
      <el-form :model="outCallForm" label-position="left" label-width="140px">
        <el-row :gutter="20" style="margin-bottom: 40px" justify="center">
          <el-col :span="18">
            <el-form-item label="受邀者入会姓名" prop="videoUrl">
              <el-input v-model="outCallForm.invitedName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-bottom: 40px" justify="center">
          <el-col :span="18">
            <el-form-item label="电话号码" prop="videoUrl">
              <el-input v-model="outCallForm.phone"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="dialog-bottom">
        <el-button type="primary" plain class="btn" @click="voiceOutCall">语音呼叫</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
  import { reactive, ref, watch, onMounted } from 'vue'
  import { ElMessage } from 'element-plus'
  import { LiveClient } from '@/utils/livekit/index';

  // const baseUrl = import.meta.env.VITE_BASE_URL || 'https://10.2.15.102'
  const baseUrl = window['$baseUrl']
  const liveForm = reactive({
    userName: '',
    loginKey: '',
    roomName: '',
    roomNumber: '',
    audioDevice: '',
    videoDevice: '',
    outputDevice: '',
    // pullMode: 'auto',
    echoCancellation: '0',
    autoGain: '0',
    noiseCancellation: '0',
    videoUrl: '',
    pushVideoUrl: '',
    currentUser: ''
  })
  let audioDeviceList = ref([]), videoDeviceList = ref([]), outputDeviceList = ref([])
  let imgUrl = ref('')
  let liveClient = null
  let isScreenShareShow = ref(false)
  let userId = ref(null)
  let org = ref(null)
  let token = ref(null)
  let outCallDialogShow = ref(false)
  let isJoinRoom = ref(false)
  const outCallForm = reactive({
    invitedName: "",
    phone: ""
  })
  watch(() => liveForm.audioDevice, (audioDevice) => {
    if(liveClient) {
      liveClient.changeAudioDevice(audioDevice)
    }
  })
  watch(() => liveForm.videoDevice, (videoDevice) => {
    if(liveClient) {
      liveClient.changeVideoDevice(videoDevice)
    }
  })
  watch(() => liveForm.outputDevice, (outputDevice) => {
    if(liveClient) {
      liveClient.changeOutputDevice(outputDevice)
    }
  })
  onMounted(async () => {
    const { audioDevices, videoDevices, outputDevices } = await LiveClient.getDeviceList()
    audioDeviceList.value = audioDevices.map(item => {
      return {
        label: item.label,
        value: item.deviceId
      }
    })
    videoDeviceList.value = videoDevices.map(item => {
      return {
        label: item.label,
        value: item.deviceId
      }
    })
    outputDeviceList.value = outputDevices.map(item => {
      return {
        label: item.label,
        value: item.deviceId
      }
    })
  })
  const login = async () => {
    let loginParams = {
      rememberme: '1',
      username: liveForm.userName.split('@')[0],
      tenantAccount: liveForm.userName.split('@')[1],
      password: liveForm.loginKey
    }
    let result = null
    try {
      let response = await fetch(baseUrl + '/api/system/loginNew', {
        method: 'POST',
        headers: {
        'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(loginParams)
      })
      result = await response.json()
    } catch(err) {
      ElMessage({
        message: '用户登录失败',
        type: 'error'
      })
    }
    if(result) {
      ElMessage({
        message: '用户登录成功',
        type: 'success'
      })
      localStorage.setItem('token', result.token)
      localStorage.setItem('username', loginParams.username)
      localStorage.setItem('tenantAccount', loginParams.tenantAccount)
      await fetchUserMsg()
    }
  }
  const fetchUserMsg = async () => {
    let tenantAccount = localStorage.getItem("tenantAccount")
    let token = localStorage.getItem("token")
    let response = await fetch(`${baseUrl}/api/tenantDetail/getTenantDetailListByPage?tenantAccount=${tenantAccount}`, {
      method: "GET",
      headers: {
        'Authorization': token
      }
    });
    let result
    try {
      result = await response.json();
    } catch (err) {
      console.error(err);
    }
    if(result) {
      // console.log('fetchUserMsg', result);
      localStorage.setItem('org', result.list[0].id)
      // screenShotOrg.value = result.list[0].id
    }
  };
  const exitRoom = () => {
    if(liveClient) {
      liveClient.leaveRoom()
      liveClient = null
    }
    location.reload()
  }
  const initRoomEvent = () => {
    // console.log('initEvent', liveClient);
    if(!liveClient) {
      return
    }
    liveClient.on("makeCallSuccess", (e) => {
      ElMessage({
        message: "外呼成功",
        type: "success",
      });
      outCallDialogShow.value = false
    });
    liveClient.on('roomCreatedSuccess', (e) => {
      console.log('roomCreatedSuccess', e);
      ElMessage({
        message: '房间创建成功，房间号为' + e,
        type: 'success'
      })
    })
    liveClient.on('roomCreatedFail', (e) => {
      console.log('roomCreatedFail', e);
      ElMessage({
        message: '房间创建失败，请重试',
        type: 'error'
      })
    })
    liveClient.on('roomConnected', (e) => {
      console.log('roomConnected', e);
      ElMessage({
        message: '房间连接成功',
        type: 'success'
      })
      isJoinRoom.value = true
    })
    liveClient.on('joinRoomError', (e) => {
      console.log('joinRoomError', e);
      ElMessage({
        message: '加入房间失败，请重试',
        type: 'error'
      })
      isJoinRoom.value = false
    })
    liveClient.on('roomDisconnected', (e) => {
      console.log('roomDisconnected', e);
      ElMessage({
        message: '房间连接已关闭',
        type: 'error'
      })
      isJoinRoom.value = false
      exitRoom()
    })
    liveClient.on('localCameraChange', (e) => {
      console.log('localCameraChange', e);
      let message = ''
      if(e) {
        message = '摄像头已打开'
      } else {
        message = '摄像头已关闭'
      }
      ElMessage({
        message: message,
        type: 'success'
      })
    })
    liveClient.on('localMicrophoneChange', (e) => {
      console.log('localMicrophoneChange', e);
      let message = ''
      if(e) {
        message = '麦克风已打开'
      } else {
        message = '麦克风已关闭'
      }
      ElMessage({
        message: message,
        type: 'success'
      })
    })
    liveClient.on('localScreenShareChange', (e) => {
      console.log('localScreenShareChange', e);
      let message = ''
      if(e) {
        message = '屏幕共享已打开'
      } else {
        message = '屏幕共享已关闭'
      }
      ElMessage({
        message: message,
        type: 'success'
      })
    })
    liveClient.on('startPushing', (e) => {
      console.log('startPushing', e);
      ElMessage({
        message: '开始视频推流',
        type: 'success'
      })
    })
    liveClient.on('stopPushing', (e) => {
      console.log('stopPushing', e);
      ElMessage({
        message: '停止视频推流',
        type: 'success'
      })
    })
    liveClient.on('startRecording', (e) => {
      console.log('startRecording', e);
      ElMessage({
        message: '开始录制',
        type: 'success'
      })
    })
    liveClient.on('stopRecording', (e) => {
      console.log('stopRecording', e);
      ElMessage({
        message: '停止录制',
        type: 'success'
      })
    })
    liveClient.on('startPulling', (e) => {
      console.log('startPulling', e);
      ElMessage({
        message: '开始拉流',
        type: 'success'
      })
    })
    liveClient.on('stopPulling', (e) => {
      console.log('stopPulling', e);
      ElMessage({
        message: '停止拉流',
        type: 'success'
      })
    })
    liveClient.on('imageUploadSuccess', (e) => {
      console.log('imageUploadSuccess', e);
      imgUrl.value = e
      ElMessage({
        message: '截屏保存成功',
        type: 'success'
      })
    })
    liveClient.on('imageUploadFail', (e) => {
      console.log('imageUploadFail', e);
      ElMessage({
        message: '截屏保存失败，请检查接口后重试',
        type: 'error'
      })
    })
    liveClient.on('screenShareRender', (e) => {
      console.log('屏幕共享渲染', e);
      let videoElm = document.getElementById('screenshare-video')
      console.log('videoElm', videoElm);
      if(e.videoTrack) {
        isScreenShareShow.value = true
        // console.log('isScreenShareShow', isScreenShareShow.value);
        if(videoElm) {
          e.videoTrack?.attach(videoElm)
        }
        console.log('videoTrack', e.videoTrack);
      }
      if(e.audioTrack) {
        if(videoElm) {
          e.audioTrack?.attach(videoElm)
        }
      }
      if(e.identity) {
        let infoDom = document.getElementById('screenshare-info')
        if(infoDom) {
          infoDom.innerHTML = e.identity
        }
      }
    })
    liveClient.on('screenShareUnrender', (e) => {
      console.log('屏幕共享取消渲染', e);
      if(isScreenShareShow.value = true) {
        isScreenShareShow.value = false
      }
    })
    liveClient.on('videoCallRender', (e) => {
      console.log('视频通话渲染', e);
      const container = document.getElementById('video-wrap')
      if(!container) {
        ElMessage({
          message: '视频会议容器不存在',
          type: 'error'
        })
        return
      }
      let div = document.getElementById(`participant-${e.identity}`)
      if(!div && !e.remove) {
        div = document.createElement('div')
        div.id = `participant-${e.identity}`
        div.className = 'participant'
        div.innerHTML = `
          <video id="video-${e.identity}" class="p-video" autoplay></video>
          <div class="describe">
            <div id="${e.identity}" class="identity">${e.name}</div>
            <div class="tools">
              <div id="camera-${e.identity}" class="camera"></div>
              <div id="microphone-${e.identity}" class="microphone"></div>
            </div>
          </div>
        `
        container.appendChild(div)
      }

      let videoElm = document.getElementById(`video-${e.identity}`)
      let microphoneElm = document.getElementById(`microphone-${e.identity}`)
      let cameraElm = document.getElementById(`camera-${e.identity}`)

      if(microphoneElm && e.isMicrophoneEnabled) {
        microphoneElm.className = 'microphone microphone-active'
        microphoneElm.onclick = () => {
          liveClient.changeParticipantMicrophoneStatus(e.identity, true)
        }
      } else if(microphoneElm && !e.isMicrophoneEnabled) {
        microphoneElm.className = 'microphone microphone-inactive'
        microphoneElm.onclick = () => {
          liveClient.changeParticipantMicrophoneStatus(e.identity, false)
        }
      }
      if(cameraElm && e.isCameraEnabled) {
        cameraElm.className = 'camera camera-active'
        cameraElm.onclick = () => {
          liveClient.changeParticipantCameraStatus(e.identity, true)
        }
      } else if(cameraElm && !e.isCameraEnabled) {
        cameraElm.className = 'camera camera-inactive'
        cameraElm.onclick = () => {
          liveClient.changeParticipantCameraStatus(e.identity, false)
        }
      }
      if(e.remove) {
        if(videoElm) {
          videoElm.srcObject = null;
          videoElm.src = "";
          videoElm?.remove()
        }
        if(div) {
          div?.remove()
        }
        return
      }
      if(e.videoTrack) {
        e.videoTrack.attach(videoElm)
      }
      if(e.audioTrack) {
        e.audioTrack.attach(videoElm)
      }
    })
    liveClient.on('audioCallRender', (e) => {
      console.log('音频通话渲染', e);
      const container = document.getElementById('audio-wrap')
      if(!container) {
        ElMessage({
          message: '音频通话容器不存在',
          type: 'error'
        })
        return
      }
      let div = document.getElementById(`participant-${e.identity}`)
      if(!div && !e.remove) {
        div = document.createElement("div");
        div.id = `participant-${e.identity}`
        div.className = "participant"
        div.innerHTML = `
          <audio class="p-audio" id="audio-${e.identity}" autoplay></audio>
          <div class="p-sandbox"></div>
          <div class="describe">
            <div id="${e.identity}" class="identity">${e.name}</div>
            <div class="tools">
              <div id="microphone-${e.identity}" class="microphone"></div>
            </div>
          </div>
        `
        container.appendChild(div)
      }
      let audioElm = document.getElementById(`audio-${e.identity}`)
      let microphoneElm = document.getElementById(`microphone-${e.identity}`)
      if(e.remove) {
        if(audioElm) {
          audioElm.srcObject = null;
          audioElm.src = "";
          audioElm?.remove()
        }
        if(div) {
          div?.remove()
        }
        return
      }
      if(microphoneElm && e.isMicrophoneEnabled) {
        microphoneElm.className = 'microphone microphone-active'
        microphoneElm.onclick = () => {
          liveClient.changeParticipantMicrophoneStatus(e.identity, true)
        }
      } else if(microphoneElm && !e.isMicrophoneEnabled) {
        microphoneElm.className = 'microphone microphone-inactive'
        microphoneElm.onclick = () => {
          liveClient.changeParticipantMicrophoneStatus(e.identity, false)
        }
      }
      if(e.audioTrack) {
        e.audioTrack.attach(audioElm)
      }
    })
  }
  const createRoom = async () => {
    userId.value = localStorage.getItem('username')
    org.value = localStorage.getItem('org')
    token.value = localStorage.getItem('token')
    if(liveForm.roomName === '') {
      console.log('请输入房间名，房间名不能为空')
      return
    }
    if(!userId.value || !org.value || !token.value) {
      console.log('创建房间前请先登录');
      return
    }
    let param = {
      userId: userId.value,
      org: org.value,
      token: token.value,
      roomName: liveForm.roomName,
      roomMode: 'audio',
      baseUrl: baseUrl
    }
    liveClient = new LiveClient(param)
    initRoomEvent()
    liveForm.roomNumber = await liveClient.createRoom()
    let joinRoomParam = {
      audioDeviceId: liveForm.audioDevice,
      videoDeviceId: liveForm.videoDevice,
      outputDeviceId: liveForm.outputDevice,
      autoGainControl: liveForm.autoGain,
      echoCancellation: liveForm.echoCancellation,
      noiseSuppression: liveForm.noiseCancellation,
      roomNum: liveForm.roomNumber
    }
    let activeDevice = null
    activeDevice = await liveClient.joinRoom(joinRoomParam)
    console.log('activeDevice', activeDevice);
    liveForm.audioDevice = activeDevice.audioInputDevice
    liveForm.videoDevice = activeDevice.videoInputDevice
    liveForm.outputDevice = activeDevice.audioOutputDevice
  }
  const enterRoom = async () => {
    userId.value = localStorage.getItem("username");
    org.value = localStorage.getItem("org");
    token.value = localStorage.getItem("token");
    let param = {
      audioDeviceId: liveForm.audioDevice,
      videoDeviceId: liveForm.videoDevice,
      outputDeviceId: liveForm.outputDevice,
      autoGainControl: liveForm.autoGain,
      echoCancellation: liveForm.echoCancellation,
      noiseSuppression: liveForm.noiseCancellation,
      roomNum: liveForm.roomNumber
    }
      let param2 = {
        userId: userId.value,
        org: org.value,
        token: token.value,
        roomName: liveForm.roomName,
        roomMode: 'audio',
        baseUrl: baseUrl
      }
      let activeDevice = null
      if(liveClient) {
        activeDevice = await liveClient.joinRoom(param)
      } else {
        liveClient = new LiveClient(param2)
        initRoomEvent()
        activeDevice = await liveClient.joinRoom(param)
      }
      console.log('activeDevice', activeDevice);
      liveForm.audioDevice = activeDevice.audioInputDevice
      liveForm.videoDevice = activeDevice.videoInputDevice
      liveForm.outputDevice = activeDevice.audioOutputDevice
  }
  const changeMicrophoneStatus = () => {
    console.log('改前', liveClient.isMicrophoneEable);
    liveClient.changeMicrophoneStatus()
  }
  const outCallInvite = () => {
    outCallDialogShow.value = true
    outCallForm.invitedName = ""
    outCallForm.phone = ""
  }
  const voiceOutCall = async () => {
    if(!outCallForm.invitedName || !outCallForm.phone) {
      ElMessage({
        message: "请先输入受邀者入会姓名和手机号",
        type: "error",
      });
    }
    await liveClient.makeCall(outCallForm.invitedName, outCallForm.phone)
  }
</script>

<style lang="scss" scoped>
  // @import "./style.scss";
  .contain {
    width: 100%;
    padding-top: 20px;
    .tip-box {
      width: 100%;
      background-color: #f4ce98;
      padding: 10px 20px;
      margin-bottom: 20px;
      font-size: 14px;
      line-height: 22px;
    }
    .btn-list {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      padding-left: 30px;
      margin-bottom: 20px;
      .btn {
        flex-shrink: 0;
        padding: 4px 10px;
        margin-right: 20px;
      }
    }
  }
  #img-box {
    margin-top: 20px;
    margin-bottom: 20px;
    .img-show {
      width: 460px;
      height: 380px;
    }
  }
  #screenshare-area {
    position: relative;
    margin-top: 20px;
    margin-bottom: 20px;
    // display: none;
  }

  #screenshare-area video {
    width: 800px;
    height: 400px;
    object-fit: fill;
    border: 3px solid rgba(0, 0, 0, 0.5);
  }
  .makecall {
    padding-top: 20px;
    padding-bottom: 20px;
    :deep(.el-form-item) {
      display: block;
    }
    :deep(.el-form-item__content) {
      padding-left: 20px;
    }
    .dialog-bottom {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 20px;
      .btn {
        padding: 0 10px;
      }
    }
  }
</style>