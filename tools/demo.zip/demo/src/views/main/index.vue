<template>
  <div class="front-page">
    <button @click="btnClick1">btn1</button>
    <button @click="btnClick2">btn2</button>
    <button @click="btnClick3">btn3</button>
    <button @click="btnClick4">btn4</button>
    <button @click="btnClick5">btn5</button>
    <button @click="btnClick6">btn6</button>
    <div :class="['contain', containClass]">
      <template v-if="containClass === 'default' || containClass === 'default2' || containClass === 'default3'">
        <div class="item item1">1</div>
        <div class="item item2">2</div>
        <div class="item item3">3</div>
        <div class="item item4">4</div>
        <div class="item item5">5</div>
        <div class="item item6">6</div>
        <div class="item item7">7</div>
        <div class="item item8">8</div>
        <div class="item item9">9</div>
        <div class="item item10">10</div>
      </template>
      <template v-else-if="containClass === 'default4'">
        
      </template>
      <template v-else-if="containClass === 'default5'">
        
      </template>
      <template v-else-if="containClass === 'default6'">
        
      </template>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
let containClass = ref("default");
const btnClick1 = () => {
  containClass.value = "default";
};
const btnClick2 = () => {
  containClass.value = "default2";
};
const btnClick3 = () => {
  containClass.value = "default3";
};
const btnClick4 = () => {
  containClass.value = "default4";
};
const btnClick5 = () => {
  containClass.value = "default5";
};
const btnClick6 = () => {
  containClass.value = "default6";
};
</script>

<style lang="scss" scoped>
.front-page {
  width: 100%;
  height: 100vh;
  position: relative;
  .contain {
    width: 300px;
    height: 200px;
  }
  .default {
    display: flex;
    flex-wrap: wrap;
    align-content: space-between;
    justify-content: space-between;
    overflow-y: auto;
    .item {
      width: 49%;
      height: 49%;
      aspect-ratio: 1/1;
    }
  }
  .default2 {
    display: flex;
    flex-wrap: wrap;
    align-content: flex-start;
    justify-content: flex-start;
    overflow-y: auto;
    .item {
      width: 33.33%;
      height: 33.33%;
    }
  }
  .default3 {
    display: flex;
    flex-wrap: wrap;
    align-content: flex-start;
    justify-content: flex-start;
    overflow-y: auto;
    .item {
      width: 25%;
      height: auto;
      aspect-ratio: 1/1;
    }
  }
  .default4 {
    .top {
      height: 50%;
    }
    .bottom {
      height: 50%;
    }
  }
  .item {
    &1 {
      background-color: #ef342a;
    }

    &2 {
      background-color: #f68f26;
    }

    &3 {
      background-color: #4ba946;
    }

    &4 {
      background-color: #0376c2;
    }

    &5 {
      background-color: #c077af;
    }

    &6 {
      background-color: #f8d29d;
    }

    &7 {
      background-color: #b5a87f;
    }

    &8 {
      background-color: #d0e4a9;
    }
    &9 {
      background-color: skyblue;
    }
  }
}
</style>
