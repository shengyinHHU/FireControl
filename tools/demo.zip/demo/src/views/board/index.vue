<template>
  <div class="contain">
    <el-form :model="liveForm" label-position="right" label-width="100px">
      <el-row :gutter="20" style="margin-bottom: 20px;">
          <el-col :span="6">
            <el-form-item label="用户名" prop="userName">
              <el-input v-model="liveForm.userName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="密码" prop="loginKey">
              <el-input type="password" v-model="liveForm.loginKey"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="房间号" prop="roomNumber">
              <el-input v-model="liveForm.roomNumber"></el-input>
            </el-form-item>
          </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-bottom: 20px;">
        <el-col :span="6">
          <el-form-item label="白板名称" prop="boardName">
            <el-input v-model="liveForm.boardName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="白板宽度" prop="boardWidth">
            <el-input v-model="liveForm.boardWidth"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="白板高度" prop="boardHeight">
            <el-input v-model="liveForm.boardHeight"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="btn-list">
      <el-button type="primary" plain class="btn" @click="login">登录</el-button>
      <button class="btn" @click="createRoom">创建房间</button>
      <button class="btn" @click="enterRoom">加入房间</button>
      <button class="btn" @click="exitRoom">退出房间</button>
      <!-- <button class="btn" @click="controlShareScreen">共享/取消共享屏幕</button> -->
      <button class="btn" @click="createBoard">创建白板</button>
    </div>
    <div class="btn-list">
      <button class="btn" @click="clickAppliance('pencil')">画笔</button>
      <button class="btn" @click="clickAppliance('line')">直线</button>
      <button class="btn" @click="clickAppliance('rectangle')">矩形</button>
      <button class="btn" @click="clickAppliance('ellipse')">椭圆</button>
      <button class="btn" @click="clickAppliance('circle')">圆形</button>
      <button class="btn" @click="clickAppliance('select')">选择</button>
      <button class="btn" @click="clickAppliance('eraser')">橡皮擦</button>
      <button class="btn" @click="handleUndo">撤销</button>
      <button class="btn" @click="clearCanvas()">清空图元</button>
      <!-- <button class="btn">撤销</button> -->
      <button class="btn" @click="clickAppliance('text')">文本</button>
      <!-- <button class="btn">加粗</button>
      <button class="btn">取消加粗</button>
      <button class="btn">斜体</button>
      <button class="btn">取消斜体</button> -->
    </div>
    <div>{{ canvasTitle }}</div>
    <div id="board-wrap" class="board-wrap">

    </div>
  </div>
</template>

<script setup>
  import {reactive, ref, computed} from 'vue'
  import { ElMessage } from "element-plus";
  import FabricCanvas from '@/utils/livekit/board.js';

  // const baseUrl = import.meta.env.VITE_BASE_URL || 'https://10.2.15.102'
  const baseUrl = window['$baseUrl']
  const liveForm = reactive({
    userName: "",
    loginKey: "",
    roomNumber: "",
    boardName: '',
    boardWidth: '',
    boardHeight: ''
  })
  let userId = ref(null);
  let org = ref(null);
  let token = ref(null);
  const canvasTitle = computed(() => {
    if(liveForm.boardName !== '') {
      if(liveForm.boardWidth !== '' && liveForm.boardHeight !== '') {
        return `${liveForm.boardName} ( ${liveForm.boardWidth} * ${liveForm.boardHeight} )`
      } else {
        return liveForm.boardName
      }
    } else {
      return ''
    }
  })
  let canvas = null
  const login = async () => {
    let loginParams = {
      rememberme: "1",
      username: liveForm.userName.split("@")[0],
      tenantAccount: liveForm.userName.split("@")[1],
      password: liveForm.loginKey,
    };
    let result = null;
    try {
      let response = await fetch(baseUrl + "/api/system/loginNew", {
        method: "POST",
        headers: {
          "Content-Type": "application/json;charset=utf-8",
        },
        body: JSON.stringify(loginParams),
      });
      if(response.status == 200) {
        result = await response.json();
      } else {
        ElMessage({
          message: "用户登录失败",
          type: "error",
        });
      }
    } catch (err) {
      ElMessage({
        message: "用户登录失败",
        type: "error",
      });
    }
    if (result) {
      ElMessage({
        message: "用户登录成功",
        type: "success",
      });
      localStorage.setItem("token", result.token);
      localStorage.setItem("username", loginParams.username);
      localStorage.setItem("tenantAccount", loginParams.tenantAccount);
      await fetchUserMsg()
    }
  };
  const fetchUserMsg = async () => {
    let tenantAccount = localStorage.getItem("tenantAccount")
    let token = localStorage.getItem("token")
    let response = await fetch(`${baseUrl}/api/tenantDetail/getTenantDetailListByPage?tenantAccount=${tenantAccount}`, {
      method: "GET",
      headers: {
        'Authorization': token
      }
    });
    let result
    try {
      result = await response.json();
    } catch (err) {
      console.error(err);
    }
    if(result) {
      // console.log('fetchUserMsg', result);
      localStorage.setItem('org', result.list[0].id)
      // screenShotOrg.value = result.list[0].id
    }
  };
  const createBoard = () => {
    let parent = document.getElementById('board-wrap')
    FabricCanvas.createCanvas({
      id: 'canvas-box',
      width: liveForm.boardWidth,
      height: liveForm.boardHeight
    }, parent)
    userId.value = localStorage.getItem("username");
    org.value = localStorage.getItem("org");
    token.value = localStorage.getItem("token");
    let param = {
      userId: userId.value,
      org: org.value,
      token: token.value,
      roomName: '测试',
      roomMode: "auto",
      baseUrl: baseUrl,
      canvasId: 'canvas-box'
    };
    canvas = new FabricCanvas(param)
  }
  const clickAppliance = (type) => {
    canvas.setDrawingTool(type)
  }
  const clearCanvas = () => {
    canvas.clearCanvas()
  }
  const handleUndo = () => {

  }
  
</script>

<style lang="scss" scoped>
  .contain {
    width: 100%;
    padding-top: 20px;
    .btn-list {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      padding-left: 30px;
      margin-bottom: 20px;
      .btn {
        flex-shrink: 0;
        padding: 4px 10px;
        margin-right: 20px;
      }
    }
    .board-wrap {
      margin-top: 20px;
      width: 100%;
      position: relative;
    }
  }
  .canvas-container {
    border: 1px solid black;
  }
</style>