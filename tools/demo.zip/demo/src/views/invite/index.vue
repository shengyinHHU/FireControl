<template>
  <div class="contain">
    <div class="tip-box">
      提示：<br />
      1、输入入会名称，然后点击加入房间即可加入会议。
    </div>
    <el-form :model="userData" label-position="right" label-width="100px">
      <el-row :gutter="20" style="margin-bottom: 40px">
        <el-col :span="8">
          <el-form-item label="入会名称" prop="userName">
            <el-input v-model="userData.userName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="房间名" prop="roomName">
            <el-input v-model="userData.roomName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="房间号" prop="roomNumber">
            <el-input v-model="userData.roomNumber"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20" style="margin-bottom: 40px">
        <el-col :span="8">
          <el-form-item label="音频设备" prop="audioDevice">
            <el-select v-model="userData.audioDevice">
              <el-option
                v-for="item of audioDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="视频设备" prop="videoDevice">
            <el-select v-model="userData.videoDevice">
              <el-option
                v-for="item of videoDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="输出设备" prop="outputDevice">
            <el-select v-model="userData.outputDevice">
              <el-option
                v-for="item of outputDeviceList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="btn-list">
      <el-button type="primary" plain class="btn" @click="enterRoom">加入房间</el-button>
      <el-button type="primary" plain class="btn" @click="exitRoom">退出房间</el-button>
      <template v-if="isJoinRoom">
        <el-button type="primary" plain class="btn" @click="changeCameraStatus">{{ isLocalCameraEnable ? '禁用摄像头' : '启用摄像头' }}</el-button>
        <el-button type="primary" plain class="btn" @click="changeMicrophoneStatus"
          >{{ isLocalMicrophoneEnable ? '禁用麦克风' : '启用麦克风' }}</el-button
        >
        <el-button type="primary" plain class="btn" @click="startRecord" v-if="!isRecording">开始录制</el-button>
        <el-button type="primary" plain class="btn" @click="stopRecord" v-else><i class="record-icon"></i>停止录制</el-button>
        <!-- <el-button type="primary" plain class="btn" @click="screenShot">截屏</el-button> -->
        <el-button type="primary" plain class="btn" @click="controlShareScreen"
          >{{ isLocalSreenShareEnable ? '取消共享屏幕' : '共享屏幕' }}</el-button
        >
        <el-button type="primary" plain class="btn" @click="invite">邀请</el-button>
      </template>
    </div>
    <div id="video-wrap"></div>
    <div id="screenshare-area" v-show="isScreenShareShow">
      <div>
        <span id="screenshare-info"></span>
        <span id="screenshare-resolution"></span>
      </div>
      <video id="screenshare-video" autoplay playsinline></video>
    </div>
    <!-- <div id="img-box">
      <h5>屏幕截图</h5>
      <img v-if="imgUrl" class="img-show" :src="imgUrl" alt="" />
    </div> -->
  </div>
  <el-dialog title="邀请链接" width="30%" v-model="inviteDialogShow" modal>
    <div class="link-content" id="link-content">
      <div class="link-title">{{ userData.userName + " " + "邀请您参加视频会议" }}</div>
      <div class="link-list">
        <div class="list-title">房间名：{{ userData.roomName }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">房间号：{{ userData.roomNumber }}</div>
      </div>
      <div class="link-list">
        <div class="list-title">房间链接：{{ userData.roomLink }}</div>
      </div>
      <div class="link-btn">
        <el-button id="copy-btn" type="info" style="padding: 0 10px" @click="copyLink"
          >一键复制</el-button
        >
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
import { onMounted, ref, reactive, watch } from "vue";
import { LiveClient } from "@/utils/livekit/index";
import qs from "qs";
import { ElMessage } from "element-plus";
import ClipboardJS from "clipboard";
// const baseUrl = import.meta.env.VITE_BASE_URL || 'https://10.2.15.102'
const baseUrl = window['$baseUrl']
const userData = reactive({
  // userName: (new Date().getTime().toString(36)) + '测试人' + Math.ceil(Math.random() * 10000),
  userName: "",
  roomName: "",
  roomNumber: "",
  audioDevice: "",
  videoDevice: "",
  outputDevice: "",
  roomLink: "",
});
let audioDeviceList = ref([]),
  videoDeviceList = ref([]),
  outputDeviceList = ref([]);
let liveClient = null;
// let userId = ref(null);
let org = ref(null);
let imgUrl = ref(null);
let isScreenShareShow = ref(false);
let inviteDialogShow = ref(false);
let isRecording = ref(false)
// 控制摄像头按钮展示
let isLocalCameraEnable = ref(true)
// 控制麦克风按钮展示
let isLocalMicrophoneEnable = ref(true)
let isLocalSreenShareEnable = ref(false)
let isJoinRoom = ref(false)
watch(
  () => userData.audioDevice,
  (audioDevice) => {
    if (liveClient) {
      liveClient.changeAudioDevice(audioDevice);
    }
  }
);
watch(
  () => userData.videoDevice,
  (videoDevice) => {
    if (liveClient) {
      liveClient.changeVideoDevice(videoDevice);
    }
  }
);
watch(
  () => userData.outputDevice,
  (outputDevice) => {
    if (liveClient) {
      liveClient.changeOutputDevice(outputDevice);
    }
  }
);
const initData = () => {
  let href = location.href;
  // "https://10.2.15.102/#/invite?roomName=%E6%B5%8B%E8%AF%95%E4%BC%9A%E8%AE%AE01&roomNum=94987910";
  let decoded = decodeURI(href);
  let index = decodeURI(href).indexOf("?");
  let data = qs.parse(decoded.substring(index + 1));
  userData.roomName = data.roomName;
  userData.roomNumber = data.roomNum;
  org.value = "default"
};
const exitRoom = () => {
  if (liveClient) {
    liveClient.leaveRoom();
    liveClient = null;
  }
  location.reload();
};
const initRoomEvent = () => {
  // console.log('initEvent', liveClient);
  if (!liveClient) {
    return;
  }
  liveClient.on("roomCreatedSuccess", (e) => {
    console.log("roomCreatedSuccess", e);
    ElMessage({
      message: "房间创建成功，房间号为" + e,
      type: "success",
    });
  });
  liveClient.on("roomCreatedFail", (e) => {
    console.log("roomCreatedFail", e);
    ElMessage({
      message: "房间创建失败，请重试",
      type: "error",
    });
  });
  liveClient.on("roomConnected", (e) => {
    console.log("roomConnected", e);
    ElMessage({
      message: "房间连接成功",
      type: "success",
    });
    isJoinRoom.value = true
  });
  liveClient.on("joinRoomError", (e) => {
    console.log("joinRoomError", e);
    ElMessage({
      message: "加入房间失败，请重试",
      type: "error",
    });
    isJoinRoom.value = false
  });
  liveClient.on("roomDisconnected", (e) => {
    console.log("roomDisconnected", e);
    ElMessage({
      message: "房间连接已关闭",
      type: "error",
    });
    isJoinRoom.value = false
    exitRoom()
  });
  liveClient.on("localCameraChange", (e) => {
    console.log("localCameraChange", e);
    let message = "";
    isLocalCameraEnable.value = e
    if (e) {
      message = "摄像头已打开";
    } else {
      message = "摄像头已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("localMicrophoneChange", (e) => {
    console.log("localMicrophoneChange", e);
    let message = "";
    isLocalMicrophoneEnable.value = e
    if (e) {
      message = "麦克风已打开";
    } else {
      message = "麦克风已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("localScreenShareChange", (e) => {
    console.log("localScreenShareChange", e);
    let message = "";
    isLocalSreenShareEnable.value = e
    if (e) {
      message = "屏幕共享已打开";
    } else {
      message = "屏幕共享已关闭";
    }
    ElMessage({
      message: message,
      type: "success",
    });
  });
  liveClient.on("startPushing", (e) => {
    console.log("startPushing", e);
    ElMessage({
      message: "开始视频推流",
      type: "success",
    });
  });
  liveClient.on("stopPushing", (e) => {
    console.log("stopPushing", e);
    ElMessage({
      message: "停止视频推流",
      type: "success",
    });
  });
  liveClient.on("startRecording", (e) => {
    console.log("startRecording", e);
    ElMessage({
      message: "开始录制",
      type: "success",
    });
    isRecording.value = true
  });
  liveClient.on("stopRecording", (e) => {
    console.log("stopRecording", e);
    ElMessage({
      message: "停止录制",
      type: "success",
    });
    isRecording.value = false
  });
  liveClient.on("startPulling", (e) => {
    console.log("startPulling", e);
    ElMessage({
      message: "开始拉流",
      type: "success",
    });
  });
  liveClient.on("stopPulling", (e) => {
    console.log("stopPulling", e);
    ElMessage({
      message: "停止拉流",
      type: "success",
    });
  });
  liveClient.on("imageUploadSuccess", (e) => {
    console.log("imageUploadSuccess", e);
    imgUrl.value = e;
    ElMessage({
      message: "截屏保存成功",
      type: "success",
    });
  });
  liveClient.on("imageUploadFail", (e) => {
    console.log("imageUploadFail", e);
    ElMessage({
      message: "截屏保存失败，请检查接口后重试",
      type: "error",
    });
  });
  liveClient.on("screenShareRender", (e) => {
    console.log("屏幕共享渲染", e);
    let videoElm = document.getElementById("screenshare-video");
    console.log("videoElm", videoElm);
    if (e.videoTrack) {
      isScreenShareShow.value = true;
      if (videoElm) {
        e.videoTrack?.attach(videoElm);
      }
      console.log("videoTrack", e.videoTrack);
    }
    if (e.audioTrack) {
      if (videoElm) {
        e.audioTrack?.attach(videoElm);
      }
    }
    if (e.identity) {
      let infoDom = document.getElementById("screenshare-info");
      if (infoDom) {
        infoDom.innerHTML = e.identity;
      }
    }
  });
  liveClient.on("screenShareUnrender", (e) => {
    console.log("屏幕共享取消渲染", e);
    if ((isScreenShareShow.value = true)) {
      isScreenShareShow.value = false;
    }
  });
  liveClient.on("videoCallRender", (e) => {
    console.log("视频通话渲染", e);
    if(liveClient) {
      isLocalCameraEnable.value = liveClient.isCameraEnable
      isLocalMicrophoneEnable.value = liveClient.isMicrophoneEnable
      isLocalSreenShareEnable.value = liveClient.isShareEnable
    }
    const container = document.getElementById("video-wrap");
    if (!container) {
      ElMessage({
        message: "视频会议容器不存在",
        type: "error",
      });
      return;
    }
    let div = document.getElementById(`participant-${e.identity}`);
    if (!div && !e.remove) {
      div = document.createElement("div");
      div.id = `participant-${e.identity}`;
      div.className = "participant";
      div.innerHTML = `
          <video id="video-${e.identity}" class="p-video" autoplay></video>
          <div class="describe">
            <div id="${e.identity}" class="identity">${e.name}</div>
            <div class="tools">
              <div id="camera-${e.identity}" class="camera"></div>
              <div id="microphone-${e.identity}" class="microphone"></div>
            </div>
          </div>
        `;
      container.appendChild(div);
    }

    let videoElm = document.getElementById(`video-${e.identity}`);
    let microphoneElm = document.getElementById(`microphone-${e.identity}`);
    let cameraElm = document.getElementById(`camera-${e.identity}`);
    const unableMicrophone = () => {
      liveClient.changeParticipantMicrophoneStatus(e.identity, true);
    };
    const enableMicrophone = () => {
      liveClient.changeParticipantMicrophoneStatus(e.identity, false);
    };
    if (microphoneElm && e.isMicrophoneEnabled) {
      microphoneElm.className = "microphone microphone-active";
      microphoneElm.onclick = unableMicrophone;
    } else if (microphoneElm && !e.isMicrophoneEnabled) {
      microphoneElm.className = "microphone microphone-inactive";
      microphoneElm.onclick = enableMicrophone;
    }
    if (cameraElm && e.isCameraEnabled) {
      cameraElm.className = "camera camera-active";
      cameraElm.onclick = () => {
        liveClient.changeParticipantCameraStatus(e.identity, true);
      };
    } else if (cameraElm && !e.isCameraEnabled) {
      cameraElm.className = "camera camera-inactive";
      cameraElm.onclick = () => {
        liveClient.changeParticipantCameraStatus(e.identity, false);
      };
    }
    if (e.remove) {
      if (videoElm) {
        videoElm.srcObject = null;
        videoElm.src = "";
        videoElm?.remove();
      }
      if (div) {
        div?.remove();
      }
      return;
    }
    if (e.videoTrack) {
      e.videoTrack.attach(videoElm);
    }
    if (e.audioTrack) {
      e.audioTrack.attach(videoElm);
    }
  });
  liveClient.on("requestDeviceOpen", (e) => {
    console.log("房主请求打开设备", e);
    if (e.input == "1") {
      ElMessage({
        message: "房主请求与会者打开麦克风",
        type: "success",
      });
    } else if (e.input == "2") {
      ElMessage({
        message: "房主请求与会者打开摄像头",
        type: "success",
      });
    }
  });
};
const setInviteLink = () => {
  // let hrefStr = location.href.split("#")[0]
  return `${window['$linkBaseUrl']}#/invite?roomName=${userData.roomName}&roomNum=${userData.roomNumber}&org=${org.value}`;
  // return `${location.protocol}//${location.host}/#/invite?roomName=${userData.roomName}&roomNum=${userData.roomNumber}&org=${org.value}`;
};
const enterRoom = async () => {
  if(!org.value) {
    console.log('租户id不能为空')
    return;
  }
  let param = {
    userId: userData.userName,
    org: org.value,
    roomMode: "auto",
    baseUrl: baseUrl
  };
  let joinParam = {
    roomNum: userData.roomNumber,
  };
  let activeDevice;
  liveClient = new LiveClient(param);
  initRoomEvent();
  activeDevice = await liveClient.joinRoom(joinParam);
  userData.roomLink = setInviteLink();
  userData.audioDevice = activeDevice.audioInputDevice;
  userData.videoDevice = activeDevice.videoInputDevice;
  userData.outputDevice = activeDevice.audioOutputDevice;
};
const changeCameraStatus = () => {
  liveClient.changeCameraStatus();
};
const changeMicrophoneStatus = () => {
  liveClient.changeMicrophoneStatus();
};
const screenShot = async () => {
  let config = {
    width: 900,
    height: 900,
    quality: 1,
  };
  let serverUrl = baseUrl + "/api/FileFind/upload/image/sample";
  await liveClient.uploadScreenShot(config, serverUrl);
};
const startRecord = async () => {
  await liveClient.startRecord();
};
const stopRecord = async () => {
  await liveClient.stopRecord();
};
const controlShareScreen = () => {
  liveClient.changeScreenShareStatus();
};
const invite = () => {
  if (!userData.userName) {
    ElMessage({
      message: "无法获取到用户名",
      type: "error",
    });
    return;
  } else if (!userData.roomName) {
    ElMessage({
      message: "无法获取到房间名",
      type: "error",
    });
    return;
  } else if (!userData.roomNumber) {
    ElMessage({
      message: "无法获取房间号，请确认房间是否创建",
      type: "error",
    });
    return;
  } else if (!userData.roomLink) {
    ElMessage({
      message: "无法获取房间链接",
      type: "error",
    });
    return;
  }
  inviteDialogShow.value = true;
};
onMounted(async () => {
  initData();
  const { audioDevices, videoDevices, outputDevices } = await LiveClient.getDeviceList();
  audioDeviceList.value = audioDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
  videoDeviceList.value = videoDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
  outputDeviceList.value = outputDevices.map((item) => {
    return {
      label: item.label,
      value: item.deviceId,
    };
  });
  // try {
  //   await enterRoom()
  // } catch (e) {
  //   console.error('加入房间报错', e);
  // }
});
</script>

<style lang="scss" scoped>
.contain {
  width: 100%;
  padding-top: 10px;
  position: relative;
  .tip-box {
    width: 100%;
    background-color: #f4ce98;
    padding: 10px 20px;
    margin-bottom: 20px;
    font-size: 14px;
    line-height: 22px;
  }
  .btn-list {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    padding-left: 30px;
    margin-bottom: 20px;
    .btn {
      flex-shrink: 0;
      padding: 4px 10px;
      margin-right: 20px;
    }
  }
  .record-icon {
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-right: 10px;
    background: url('../../assets/image/demo/record.png') no-repeat center / 100% 100%;
  }
}
#img-box {
  margin-top: 20px;
  margin-bottom: 20px;
  h5 {
    padding-left: 20px;
    position: relative;
    &::before {
      content: '';
      width: 4px;
      height: 80%;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      position: absolute;
      background-color: #4868A9;
    }
  }
  .img-show {
    width: 460px;
    height: 380px;
  }
}
#screenshare-area {
  position: relative;
  margin-top: 20px;
  margin-bottom: 20px;
  // display: none;
}
#screenshare-area video {
  width: 800px;
  height: 400px;
  object-fit: fill;
  border: 3px solid rgba(0, 0, 0, 0.5);
}
.link-content {
  width: 100%;
  font-size: 14px;
  color: #000;
  padding-top: 30px;
  padding-bottom: 20px;
  border-top: 1px solid rgba(0, 0, 0, 0.4);
  .link-list {
    width: 100%;
    display: flex;
    align-items: flex-start;
    margin-top: 15px;
    .list-title {
      line-height: 23px;
      white-space: wrap;
    }
  }
  .link-btn {
    width: 100%;
    display: flex;
    justify-content: center;
  }
}
</style>
<style lang="scss">
  .el-dialog__body {
    padding: 0 20px;
  }
</style>