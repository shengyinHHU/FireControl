<template>
  <div>
    <h2>{{msg}}</h2>
    <button @click="btnClick()">点击</button>
    <h4>{{counter}}</h4>
    <h4>{{name}}</h4>
    <h4>{{age}}</h4>
  </div>
</template>

<script setup>
  import { ref } from 'vue'
  import { storeToRefs } from 'pinia'
  import {useStore} from '../store/index'
  defineProps({
    msg: String
  })
  const store = useStore()
  const {counter, name, age} = storeToRefs(store)
  const btnClick = () => {
    store.counter++
  }
  store.$reset()
</script>

<style lang="scss" scoped>

</style>