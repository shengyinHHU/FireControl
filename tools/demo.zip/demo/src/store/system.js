import { defineStore } from "pinia";

export const useSystemStore = defineStore('system', {
  state: () => {
    return {
      // 换肤功能
      currentSkin: 'daylight'
    }
  },
  
})