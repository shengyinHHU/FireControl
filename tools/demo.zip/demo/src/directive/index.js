export default {
  drag: (app) => {
    app.directive('drag', (el, binding) => {
      el.onmousedown = (e) => {
        let disX = e.clientX - el.offsetLeft
        let disY = e.clientY - el.offsetTop
        el.onmousemove = function (e) {
          //计算需要移动的距离
          let tX = e.clientX - disX
          let tY = e.clientY - disY
          //移动当前元素
          if (tX >= 0 && tX <= window.innerWidth - el.offsetWidth) {
            el.style.left = tX + 'px'
          }
          if (tY >= 0 && tY <= window.innerHeight - el.offsetHeight) {
            el.style.top = tY + 'px'
          }
        }
        el.onmouseup = function (e) {
          el.onmousemove = null
          el.onmouseup = null
        }
      }
      el.onwheel = function (e) {
        let parentWidth = el.parentNode.clientWidth
        let parentHeight = el.parentNode.clientHeight
        console.log('parent', parentWidth, parentHeight)
      }
    })
  }
}