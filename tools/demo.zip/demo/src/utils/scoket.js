class Socket {
  ws = null;
  // status = null;
  // pingInterval = null;
  // timeout = 10000;

  constructor(option) {
    this.url = option.url;
    this.callback = option.msgHandle;
    // this.isHeart = option.isHeart;
    // this.isReconnection = option.isReconnection;
    // this.heartCheckData = option.heartCheckData;
    // this.reconnectTime = option.reconnectTimel
  }
  connect(data) {
    this.ws = new WebSocket(this.url);
    this.ws.onopen = (e) => {
      // this.status = "open";
      console.log("链接成功", e);
      // if (this.isHeart) {
      //   this.heartCheck();
      // }
      if (data) {
        return this.ws.send(JSON.stringify({ type: "init" }));
      }
    };
    this.ws.onmessage = (e) => {
      if (typeof this.callback === "function") {
        console.log("message", e);
        this.callback(JSON.parse(e.data));
      } else {
        console.log("msgHandle须为回调函数");
      }
    };
    this.ws.onclose = (e) => {
      console.log("链接关闭", e);
      this.closeSocket(e);
    };
    this.ws.onerror = (e) => {
      console.log("链接错误", e);
      this.closeSocket(e);
    };
  }
  // 发送消息
  sendMessage(data) {
    let msg = JSON.stringify(data);
    console.log('message', msg);
    this.ws.send(msg);
  }
  // 心跳检测
  // heartCheck() {
  //   this.pingInterval = setInterval(() => {
  //     if (this.ws.readyState === 1) {
  //       this.ws.send(JSON.stringify(this.heartCheckData));
  //     }
  //   }, this.timeout);
  // }
  // 关闭心跳检测
  // resetHeart() {
  //   if (this.pingInterval) {
  //     clearInterval(this.pingInterval);
  //   }
  // }
  // closeSocket(e) {
  //   this.resetHeart();
  //   if (this.status !== "close") {
  //     console.log("断线，重连中。。。", e);
  //     if (this.isReconnection) {
  //       if(this.reconnectTime > 0) {
  //         this.reconnectTime--
  //         this.connect();
  //       } else {
  //         console.log('重连次数过多, 断开链接');
  //         this.close()
  //       }
  //     }
  //   } else {
  //     console.log("手动关闭了", e);
  //   }
  // }
  close() {
    // this.status = "close"
    // this.resetHeart()
    return this.ws.close()
  }
}
export { Socket };
