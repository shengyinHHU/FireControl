import axios from 'axios'

const baseURL = window['$baseUrl']
const instance = axios.create({
  baseURL,
  timeout: 30000
})
// instance.defaults.headers.common['Content-Type'] = 'application/json'

// 请求拦截
instance.interceptors.request.use((config) => {
  console.log('config', config)
  return config
}, (err) => {
  return Promise.reject(err)
})
// 响应拦截
instance.interceptors.response.use((response) => {
  console.log('response', response);
  return response
}, (err) => {
  return Promise.reject(err)
})

export default instance