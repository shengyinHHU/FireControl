/**
 * 表单常用正则判断
 * 关键信息添加*号
 */

// 身份证校验
const verifyIdentity = (type, value) => {
  let result = false
  let message = ''
  switch(type) {
    case '身份证':
      let reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
      result = reg.test(value)
      message = '身份证号码不合法'
    case '港澳台身份证':
      reg = /^[1|5|7][0-9]{6}\([0-9Aa]\)/
      let isAomen = reg.test(value)
      reg = /^((\s?[A-Za-z])|([A-Za-z]{2}))\d{6}(\([0−9aA]\)|[0-9aA])$/
      let isHongkang = reg.test(value)
      reg = /^[a-zA-Z][0-9]{9}$/
      let isTaiwan = reg.test(value)
      result = isAomen || isHongkang || isTaiwan
      message = '身份证号码不合法'
    default:
      result = true
  }
  return {
    message,
    result
  }
}
// 手机号码校验
const verifyPhone = (phoneNum) => {
  const reg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
  return reg.test(phoneNum)
}
// 车牌号校验
const verifyCarPlate = (value) => {
  // 普通车牌
  const ordinary = /[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳]{1}/
  // 新能源车牌
  const newEnergy = /[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}(([0-9]{5}[DF])|([DF][A-HJ-NP-Z0-9][0-9]{4}))/
  return ordinary.test(value) || newEnergy.test(value)
}
// 手机号隐藏中间四位
const hidePhone = (phoneNum) => {
  if(verifyPhone(phoneNum)) {
    return phoneNum.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")
  } else {
    return;
  }
}
// 大陆身份证号隐藏年月日
const hideId = (id) => {
  let result = null
  switch(id.length) {
    case 15:
      result = id.replace(/(\d{6})\d{6}(\d{3})/, "$1******$2")
      break;
    case 18:
      result = id.replace(/(\d{6})\d{8}(\d{3}[0-9Xx]{1})/, "$1********$2")
      break;
    default:
      break;
  }
  return result;
}

export { verifyIdentity, verifyCarPlate, hidePhone, hideId }
