import { ElMessage, ElMessageBox } from 'element-plus'
// 展示顶部消息提示
const showMessage = (type = '', message = '', duration = 3000) => {
  ElMessage({
    message,
    type,
    duration,
    grouping: true
  })
}
// 打开消息确认框
const openMessageBox = ({ type = '', title = '', content = '', confirmText = '确认', cancelText = '取消' } = {}, confirmCallback, cancelCallback) => {
  ElMessageBox.confirm(
    content,
    title,
    {
      type,
      confirmButtonText: confirmText,
      cancelButtonText: cancelText,
      draggable: true
    }
  ).then(() => {
    confirmCallback ? confirmCallback() : console.log('点击确认');
  }).catch(() => {
    cancelCallback ? cancelCallback() : console.log('点击取消');
  })
}

export { showMessage, openMessageBox }