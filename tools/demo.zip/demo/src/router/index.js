import { createRouter, createWebHashHistory } from 'vue-router'
import { routes } from './routes'
import qs from 'qs'

const router = createRouter({
  routes,
  history: createWebHashHistory(),
  parseQuery: qs.parse,
  stringifyQuery: qs.stringify
})
router.beforeEach((to, from) => {
  let query = to.query
  if(to.path === '/liveKit' || to.path === '/liveKit2') {
    sessionStorage.setItem('token', query.token)
    sessionStorage.setItem('username', query.username)
    sessionStorage.setItem('org', query.org)
  }
})
export default router