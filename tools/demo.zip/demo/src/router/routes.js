const routes = [
  {
    path: '/',
    redirect: '/liveKit'
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/views/main/index.vue')
  },
  {
    path: '/liveKit',
    name: 'livekit',
    component: () => import('@/views/livekit/index.vue')
  },
  {
    path: '/liveKit2',
    name: 'livekit2',
    component: () => import('@/views/livekit/index2.vue')
  },
  {
    path: '/invite',
    name: 'invite',
    component: () => import('@/views/invite/index.vue')
  },
  // {
  //   path: '/board',
  //   name: 'board',
  //   component: () => import('@/views/board/index.vue')
  // }
]

export { routes }