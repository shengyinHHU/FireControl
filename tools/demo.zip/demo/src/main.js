import { createApp } from 'vue'
import router from '@/router/index'
import App from './App.vue'
import { createPinia } from 'pinia'
import directives from './directive/index'
import ElementPlus from 'element-plus'

import 'element-plus/dist/index.css'

const app = createApp(App)
directives.drag(app)
app.use(createPinia())
app.use(router)
app.use(ElementPlus)
app.mount('#app')
