import http from '@/utils/axiosHttp.js'

export const getMiniLink = (data = {}, headers = {}) => {
  return http.post('/api/v1/getWXUrlLink', data, {
    headers
  })
}