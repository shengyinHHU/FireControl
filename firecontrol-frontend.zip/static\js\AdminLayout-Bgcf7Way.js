import{o as a,q as e,n as r,ax as t}from"./index-I0QcMt-3.js";const _={__name:"AdminLayout",setup(o){return(s,n)=>(a(),e(r(t),{class:"fire-admin fire-theme"}))}};export{_ as default};
