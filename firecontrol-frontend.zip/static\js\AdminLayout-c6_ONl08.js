import{o as a,q as e,n as r,av as t}from"./index-CCHl4J4e.js";const _={__name:"AdminLayout",setup(o){return(s,n)=>(a(),e(r(t),{class:"fire-admin fire-theme"}))}};export{_ as default};
