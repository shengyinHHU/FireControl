import{o as a,q as e,n as r,as as s}from"./index-sS-Hfx4l.js";const _={__name:"AdminLayout",setup(t){return(o,n)=>(a(),e(r(s),{class:"fire-admin fire-theme"}))}};export{_ as default};
